# Laravel Point Of Sale
Laravel Base Point Of Sale

![App Screen Shot](repo_screenshots/img1.png)
